<?php

namespace App\Http\Controllers\Dashboard;

use Illuminate\Http\Request;

class OrderController extends Controller
{
    //
}
