<?php

namespace App\Http\Controllers\Dashboard;

use Illuminate\Http\Request;

class OrderItemController extends Controller
{
    //
}
