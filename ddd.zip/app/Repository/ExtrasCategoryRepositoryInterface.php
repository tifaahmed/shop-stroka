<?php

namespace App\Repository;

interface ExtrasCategoryRepositoryInterface extends EloquentRepositoryInterface{
}
