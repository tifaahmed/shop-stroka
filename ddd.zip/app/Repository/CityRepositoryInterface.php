<?php

namespace App\Repository;

interface CityRepositoryInterface extends EloquentRepositoryInterface{
}
