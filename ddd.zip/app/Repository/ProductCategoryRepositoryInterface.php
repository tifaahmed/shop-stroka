<?php

namespace App\Repository;

interface ProductCategoryRepositoryInterface extends EloquentRepositoryInterface{
}
