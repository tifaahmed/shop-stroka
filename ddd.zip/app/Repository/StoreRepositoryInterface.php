<?php

namespace App\Repository;

interface StoreRepositoryInterface extends EloquentRepositoryInterface{
}
