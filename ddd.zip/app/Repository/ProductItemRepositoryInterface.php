<?php

namespace App\Repository;

interface ProductItemRepositoryInterface extends EloquentRepositoryInterface{
}
